package com.htlive.monitor;
import org.json.JSONArray;
import org.json.JSONObject;
/** Portfolio path, target reach, post-goal hold and remaining-time guardrails. */
public final class ScorePathTest {
    private static int checks=0;
    private static void yes(boolean cond,String msg){if(!cond)throw new AssertionError(msg);checks++;}
    private static JSONObject bet(String role,String pick){return new JSONObject().put("role",role).put("pick",pick).put("closed",false);}
    private static JSONObject side(int shots,int on,int box,double xg){return new JSONObject().put("shots",shots).put("on",on).put("box",box).put("xg",xg);}
    private static JSONObject now(int h,int a,int minute,long at){return new JSONObject().put("status","1H").put("minute",minute).put("h",h).put("a",a).put("lastStatsAt",at);}
    private static JSONArray three(String p1,String p2,String p3){return new JSONArray().put(bet("主单",p1)).put(bet("保险1",p2)).put(bet("保险2",p3));}
    private static JSONObject withWindow(JSONObject data,JSONObject h,JSONObject a){
        JSONObject window=new JSONObject().put("minutes",5).put("home",h).put("away",a);
        return data.put("stats",new JSONObject().put("available",true))
            .put("goalWarning",new JSONObject().put("five",window));
    }
    public static void main(String[] ignored)throws Exception{
        long t=1_000_000L;
        JSONArray cover=three("0-0","1-0","0-1");
        JSONObject kickoff=ScoreGuardEngine.analyze(now(0,0,1,t),cover,t);
        yes(kickoff.optInt("hit")==1 && kickoff.optInt("pending")==2,"0-0 hit, other scores pending");
        yes(kickoff.optJSONObject("nextHome").optInt("hit")==1 &&
            kickoff.optJSONObject("nextHome").optString("matched").contains("1-0"),"home goal activates 1-0 insurance");
        yes(kickoff.optJSONObject("nextAway").optInt("hit")==1 &&
            kickoff.optJSONObject("nextAway").optString("matched").contains("0-1"),"away goal activates 0-1 insurance");
        yes(kickoff.optString("level").equals("UNKNOWN"),"0-0 at kickoff is not a safe score");
        JSONArray options=three("1-0","2-0","1-1");
        JSONObject goal=ScoreGuardEngine.analyze(now(1,0,25,t),options,t);
        yes(goal.optInt("hit")==1 && goal.optInt("pending")==2,"1-0 hit, alternatives still pending");
        yes(goal.optJSONObject("nextHome").optString("matched").contains("2-0"),"2-0 insurance from 1-0");
        yes(goal.optJSONObject("nextAway").optString("matched").contains("1-1"),"1-1 insurance from 1-0");
        JSONArray only=new JSONArray().put(bet("主单","1-0"));
        JSONObject target=now(0,0,27,t);
        withWindow(target,side(3,2,2,.45),side(0,0,0,0));
        JSONObject reach=ScoreGuardEngine.analyze(target,only,t);
        yes("REACH_WATCH".equals(reach.optString("level")),"target-side fresh attack supports monitoring attainability");
        yes(reach.optString("reachLevel").equals("ATTACK_SUPPORTED"),"label is evidential, not a probability");
        target.put("lastStatsAt",t-100_000L);
        JSONObject stale=ScoreGuardEngine.analyze(target,only,t);
        yes(!"REACH_WATCH".equals(stale.optString("level")),"stale data does not support reaching target");
        JSONArray longWay=new JSONArray().put(bet("主单","2-0"));
        JSONObject late=ScoreGuardEngine.analyze(now(0,0,42,t),longWay,t);
        yes("TIME_TIGHT".equals(late.optString("reachLevel")),"remaining regular time considered for 2-goal gap");
        yes("PENDING".equals(late.optString("level")),"late multi-goal gap not called mathematically impossible");
        JSONObject red=now(1,0,30,t).put("newRed",true);
        JSONObject disruption=ScoreGuardEngine.analyze(red,only,t);
        yes("WATCH".equals(disruption.optString("level")),"red changes holding structure even without statistics");
        yes(disruption.optString("reason").contains("红牌"),"red gives explicit uncertainty explanation");
        JSONArray exited=three("1-0","2-0","1-1");
        exited.optJSONObject(1).put("closed",true);
        JSONObject oneMore=ScoreGuardEngine.analyze(now(1,0,26,t),exited,t);
        yes(oneMore.optJSONObject("nextHome").optInt("hit")==0,"manually closed insurance not counted as live coverage");
        yes(oneMore.optJSONObject("nextAway").optInt("hit")==1,"other active insurance still covers next away goal");
        System.out.println("PASS: "+checks+" ScorePath target/path/hold assertions");
    }
}
