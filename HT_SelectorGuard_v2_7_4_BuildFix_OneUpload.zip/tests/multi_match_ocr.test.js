/* Multi-match regression tests: one long screenshot, separate images, split OCR lines. */
const assert=require('node:assert/strict');
const fs=require('node:fs'),vm=require('node:vm');
const ctx={};vm.runInNewContext(fs.readFileSync('app/src/main/assets/import_parser.js','utf8'),ctx);
const {parse,match}=ctx.HTImportParser;
const ids=['1632035','981234','1632037','1632038'];
const pairs=[['Deportivo Recoleta','Rubio NU'],['AC Milan','Roma'],['Man City','Liverpool'],['Paris Saint Germain','Monaco']];
const times=['19:20','20:00','21:30','22:00'];
const api=ids.map((id,i)=>({id,home:pairs[i][0],away:pairs[i][1],kickoff: new Date(`2026-10-16T${times[i]}:00-03:00`).toISOString(),league:'Test'}));
const all=pairs.map((p,i)=>`2026-10-16 ${times[i]} 开赛\n${p[0]} vs ${p[1]}\nFixture ID: ${ids[i]}`).join('\n');
let out=parse({ocrEdited:true,ocrText:all});
assert.equal(out.items.length,4,'four individual matches from one tall screenshot');
assert.deepEqual(Array.from(out.items,x=>x.fixtureId),ids);
assert.equal(match(out,api).matched.length,4,'all four fixtures verified');
// An ID can occur above its team names; it must never get assigned to the PREVIOUS match.
const idFirst=pairs.map((p,i)=>`2026-10-16 ${times[i]} 开赛\nFixture ID: ${ids[i]}\n${p[0]} vs ${p[1]}`).join('\n');
out=parse({ocrEdited:true,ocrText:idFirst});
assert.equal(out.items.length,4);
assert.deepEqual(Array.from(out.items,x=>x.fixtureId),ids);
assert.equal(match(out,api).matched.length,4);
// Mixed masked/regular OCR lines are out of order; use screen Y to sort all cards.
const lines=[];
for(let i=0;i<4;i++){
 const y=40+i*235;
 lines.push({t:`Fixture ID: ${ids[i]}`,x:95,y:y+135,h:24,color:'white'});
 lines.push({t:`${pairs[i][0]} vs ${pairs[i][1]}`,x:95,y:y+68,h:26,color:'white'});
 lines.push({t:`2026-10-16 ${times[i]} 开赛`,x:95,y,h:31,color:'green'});
}
lines.reverse();
out=parse({ocrEdited:false,ocrLines:lines,ocrText:all});
assert.equal(out.items.length,4);
assert.equal(match(out,api).matched.length,4);
// Multiple screenshots can be parsed and verified independently without resetting other IDs.
for(let i=0;i<4;i++){
 const one=parse({ocrEdited:true,ocrText:`2026-10-16 ${times[i]} 开赛\n${pairs[i][0]} vs ${pairs[i][1]}\nFixture ID: ${ids[i]}`});
 assert.equal(one.items.length,1);
 assert.equal(match(one,api).matched[0].id,ids[i]);
}
// Split team names and Fixture ID from OCR must still be correctly associated.
const split=parse({ocrEdited:true,ocrText:`2026-10-16 19:20 开赛\nDeportivo Recoleta\nvs\nRubio NU\nFixture ID:\n1632035`});
assert.equal(split.items.length,1);
assert.equal(split.items[0].fixtureId,'1632035');
assert.equal(match(split,api).matched.length,1);
// A wrong fixture ID must not be substituted with another match just because the teams match.
const corrupted=parse({ocrEdited:true,ocrText:all.replace('1632035','1632036')});
assert.equal(match(corrupted,api).matched.length,3);
// Never silently truncate 12 detected and verified fixtures to the first entry.
const batch=Array.from({length:12},(_,i)=>`2026-10-16 19:20 开赛\nTeam${i+100} vs Guest${i+100}\nFixture ID: ${1800100+i}`).join('\n');
const parsedBatch=parse({ocrEdited:true,ocrText:batch});
assert.equal(parsedBatch.items.length,12);
const fixtures12=Array.from({length:12},(_,i)=>({id:String(1800100+i),home:`Team${i+100}`,away:`Guest${i+100}`,kickoff:'2026-10-16T22:20:00Z'}));
assert.equal(match(parsedBatch,fixtures12).matched.length,12);
console.log('PASS: multi-match OCR: 4-card long screenshot, 12 fixtures, ID-before-team, OCR line order, split team/ID, multi-photo, strict verification');
