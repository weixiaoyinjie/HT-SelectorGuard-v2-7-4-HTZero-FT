// Source-level regression guard; this does not replace an Android PendingIntent device test.
const fs=require('fs');const path=require('path');const assert=require('assert');
const root=path.join(__dirname,'..','app','src','main');
const read=(p)=>fs.readFileSync(path.join(root,p),'utf8');
const alert=read('java/com/htlive/monitor/AlertNotifier.java');
const detail=read('java/com/htlive/monitor/DetailPopupActivity.java');
const svc=read('java/com/htlive/monitor/MonitorService.java');
const main=read('java/com/htlive/monitor/MainActivity.java');
const manifest=read('AndroidManifest.xml');
assert(alert.includes('Intent open=new Intent(ctx,DetailPopupActivity.class)'), 'Risk and timed alerts must not target the main screen');
for(const value of ['open.putExtra("id",id)','open.putExtra("title",title)','open.putExtra("detail",detail)'])assert(alert.includes(value));
assert(detail.includes('fixtureId.equals(candidate.optString("id"))'), 'Cached report must match only the notified fixture');
assert(detail.includes('open.putExtra(MainActivity.EXTRA_FOCUS_FIXTURE,fixtureId)'), 'Scores editor must open selected fixture');
assert(detail.includes('SelectorMonitorSync.fullTime(this,fixtureId)'), 'FT statistical refresh must not be treated as half-time');
assert(svc.includes('RUNNING_MATCH_DETAIL_'), 'Single-fixture persistent notification must show details');
assert(svc.includes('MainActivity.EXTRA_LIVE_RESULTS,true'), 'Multiple fixtures must open results section');
assert(main.includes('EXTRA_LIVE_RESULTS'), 'Main activity must honor results deep link');
assert(manifest.includes('android:name="com.htlive.monitor.DetailPopupActivity"'));
console.log('notification detail routing v2.6: PASS');
