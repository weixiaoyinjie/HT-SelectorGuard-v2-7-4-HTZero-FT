package com.htlive.watch44;

import org.json.JSONArray;
import org.json.JSONObject;

/** Compact watch-only presentation. Never substitutes guesses for the phone's analysis. */
final class WearBrief {
    static final class Pick {
        final String label, state;
        final int color;
        Pick(String label, String state, int color) {
            this.label=label;this.state=state;this.color=color;
        }
    }
    final String header, teams, score, risk, action, dataLabel, ageLabel;
    final Pick[] picks;
    final String level;

    private WearBrief(String header,String teams,String score,String risk,String action,
                      String dataLabel,String ageLabel,String level,Pick[] picks) {
        this.header=header;this.teams=teams;this.score=score;this.risk=risk;
        this.action=action;this.dataLabel=dataLabel;this.ageLabel=ageLabel;
        this.level=level;this.picks=picks;
    }
    static WearBrief from(JSONObject j,long now){
        if(j==null)j=new JSONObject();
        int minute=j.optInt("minute",-1);
        String kind=j.optString("kind","比分预警");
        String header=("FT".equals(j.optString("period"))?"全场":"半场")+" · "+(kind.length()>18?"赛况预警":kind)+(minute>=0?" · "+minute+"′":"");
        String rawTeams=j.optString("teams","比赛信息待核实");
        String risk=j.optString("riskTitle","");
        if(risk.isEmpty())risk=j.optString("line2","风险待核实");
        String action=j.optString("riskAction","");
        if(action.isEmpty())action=j.optString("line3","查看手机分析");
        // Only the phone's existing conclusion can trigger a settlement-price reminder.
        // No automated cash-out decision is made on the watch.
        JSONArray list=j.optJSONArray("bets");
        int count=list==null?0:Math.min(3,list.length());
        Pick[] picks=new Pick[count];
        for(int i=0;i<count;i++){
            JSONObject bet=list.optJSONObject(i);
            if(bet==null){picks[i]=new Pick("单据待核对","待核",0xffd1dce5);continue;}
            String role=bet.optString("role",i==0?"主单":"保险"+i);
            String shortRole=role.startsWith("主")?"主":role.startsWith("保")?"保":"单";
            String p=bet.optString("pick","?");
            String status=bet.optString("state","");
            if(bet.optBoolean("closed",false))status="CLOSED";
            String label=shortRole+p;
            String text="待核";int color=0xffcddbe7;
            switch(status){
                case "HIT":text="命中中";color=0xff66e5b3;break;
                case "PENDING":text="待达";color=0xffffd07e;break;
                case "BROKEN":text="失效";color=0xffff8989;break;
                case "CLOSED":text="已结";color=0xffa7b8c8;break;
            }
            picks[i]=new Pick(label,text,color);
        }
        if(count==0 && !j.optBoolean("timed",false)) {
            // Missing picks is not proof that the user never placed a bet.
            risk="下单比分未同步 · "+risk;
        }
        long sourceAt=j.optLong("sourceAt",0L);
        String age;
        if(sourceAt<=0)age="赛况时间未知";
        else if(now-sourceAt < -30000L)age="请核对设备时间";
        else if(now-sourceAt > 120000L)age="⚠赛况滞后"+((now-sourceAt)/1000)+"秒";
        else age="赛况"+(Math.max(0,now-sourceAt)/1000)+"秒前";
        String stats=j.has("statsFresh") ?
            (j.optBoolean("statsFresh",false)?"统计已采集":"统计缺失/滞后") : "统计状态待核实";
        return new WearBrief(header,rawTeams,j.optString("score","?-?"),risk,action,
            stats,age,j.optString("level",""),picks);
    }
    String pickLine(){
        if(picks.length==0)return "下单比分：未同步";
        StringBuilder b=new StringBuilder();
        for(Pick p:picks){if(b.length()>0)b.append("  ");b.append(p.label).append(' ').append(p.state);}
        return b.toString();
    }
    String nativeTitle(){return header+"  "+score;}
    String nativePreview(){
        return pickLine()+" · "+action;
    }
    String nativeExpanded(){
        return teams+" · "+score+"\n"+pickLine()+"\n"+risk+"\n"+action+"\n"+dataLabel+" · "+ageLabel;
    }
}
